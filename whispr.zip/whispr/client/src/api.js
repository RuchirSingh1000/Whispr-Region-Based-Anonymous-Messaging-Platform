const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';

async function ensureAuth() {
  let token = localStorage.getItem('whispr_token');
  if (!token) {
    const res = await fetch(`${API}/api/auth/anonymous`, { method: 'POST' });
    const data = await res.json();
    token = data.token; localStorage.setItem('whispr_token', token); localStorage.setItem('whispr_user', data.user.id);
  }
  return token;
}

export async function getGroups() {
  const res = await fetch(`${API}/api/groups`);
  return res.json();
}

export async function getPosts(groupId, limit = 50) {
  const url = new URL(`${API}/api/posts`);
  url.searchParams.set('group_id', groupId);
  url.searchParams.set('limit', String(limit));
  const token = await ensureAuth();
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  return res.json();
}

export async function createPost({ content, group_id, reply_to }) {
  const token = await ensureAuth();
  const res = await fetch(`${API}/api/posts`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ content, group_id, reply_to })
  });
  return res.json();
}

export async function toggleLike(postId) {
  const token = await ensureAuth();
  const res = await fetch(`${API}/api/posts/${postId}/like`, { method: 'POST', headers: { Authorization: `Bearer ${token}` } });
  return res.json();
}

export async function getTrending(groupId) {
  const token = await ensureAuth();
  const url = new URL(`${API}/api/posts/trending`);
  url.searchParams.set('group_id', groupId);
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  return res.json();
}
