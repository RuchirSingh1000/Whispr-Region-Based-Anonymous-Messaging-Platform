import React, { useEffect, useState, useMemo } from 'react'
import Header from './components/Header.jsx'
import Sidebar from './components/Sidebar.jsx'
import Rightbar from './components/Rightbar.jsx'
import Feed from './components/Feed.jsx'
import Composer from './components/Composer.jsx'
import GroupSelector from './components/GroupSelector.jsx'
import { getGroups, getPosts, createPost } from './api.js'

export default function App() {
  const [groups, setGroups] = useState([])
  const [currentGroup, setCurrentGroup] = useState(null)
  const [posts, setPosts] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    (async () => {
      const gs = await getGroups()
      setGroups(gs)
      const saved = localStorage.getItem('whispr_group')
      const initial = gs.find(g => g.id === saved) || gs[0]
      setCurrentGroup(initial || null)
    })()
  }, [])

  useEffect(() => {
    if (!currentGroup) return
    localStorage.setItem('whispr_group', currentGroup.id)
    setLoading(true)
    getPosts(currentGroup.id, 50).then(data => { setPosts(data); setLoading(false) })
  }, [currentGroup])

  async function onPost(content) {
    if (!content.trim() || !currentGroup) return
    const created = await createPost({ content, group_id: currentGroup.id })
    setPosts(p => [created, ...p])
  }

  const title = useMemo(() => currentGroup ? currentGroup.name : 'Whispr', [currentGroup])

  return (
    <div className="app">
      <div className="sidebar card"><Sidebar /></div>
      <main className="feed card">
        <Header title={title} />
        <div style={{ padding: 16 }}>
          <GroupSelector groups={groups} current={currentGroup} onChange={setCurrentGroup} />
        </div>
        <Composer onPost={onPost} />
        <Feed posts={posts} loading={loading} />
      </main>
      <div className="rightbar card"><Rightbar currentGroup={currentGroup} /></div>
    </div>
  )
}
