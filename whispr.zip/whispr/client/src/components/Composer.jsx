import React, { useState } from 'react'

export default function Composer({ onPost }) {
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit() {
    if (!text.trim()) return
    setBusy(true)
    try { await onPost(text); setText('') } finally { setBusy(false) }
  }

  return (
    <div className="composer">
      <div className="avatar" />
      <div style={{ flex: 1 }}>
        <textarea value={text} onChange={e => setText(e.target.value)} placeholder="Share a whisper…" maxLength={500} />
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8 }}>
          <div style={{ color: '#8899a6' }}>{text.length}/500</div>
          <button className="btn" onClick={submit} disabled={busy}>{busy ? 'Posting…' : 'Whisper'}</button>
        </div>
      </div>
    </div>
  )
}
