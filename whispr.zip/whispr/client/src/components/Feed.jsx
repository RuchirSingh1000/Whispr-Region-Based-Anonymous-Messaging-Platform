import React from 'react'
import Post from './Post.jsx'

export default function Feed({ posts, loading }) {
  function updatePost(updated) {
    const idx = posts.findIndex(p => p.id === updated.id)
    if (idx >= 0) posts.splice(idx, 1, updated)
  }

  if (loading) return <div style={{ padding: 16 }}>Loading…</div>
  if (!posts || posts.length === 0) return <div style={{ padding: 16 }}>No whispers yet. Start the conversation!</div>

  return (
    <div>
      {posts.map(p => <Post key={p.id} post={p} onUpdate={updatePost} />)}
    </div>
  )
}
