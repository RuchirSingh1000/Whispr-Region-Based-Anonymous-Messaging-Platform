import React from 'react'

export default function Header({ title }) {
  return (
    <div className="header">
      <strong>{title}</strong>
      <div style={{ color: '#8899a6', fontWeight: 600 }}>Anonymous</div>
    </div>
  )
}
