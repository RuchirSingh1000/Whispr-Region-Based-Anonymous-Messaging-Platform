import React from 'react'
import { toggleLike } from '../api.js'

export default function Post({ post, onUpdate }) {
  const [liked, setLiked] = React.useState(false)

  async function like() {
    const { liked: isLiked, post: updated } = await toggleLike(post.id)
    setLiked(isLiked)
    onUpdate(updated)
  }

  return (
    <div className="post">
      <div className="avatar" />
      <div className="content">
        <div className="meta">Anonymous · {new Date(post.created_at).toLocaleString()}</div>
        <div style={{ whiteSpace: 'pre-wrap' }}>{post.content}</div>
        <div className="actions">
          <div className={"action" + (liked ? ' liked' : '')} onClick={like}>❤ {post.likes}</div>
        </div>
      </div>
    </div>
  )
}
