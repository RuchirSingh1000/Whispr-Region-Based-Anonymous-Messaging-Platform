import React, { useEffect, useState } from 'react'
import { getTrending } from '../api.js'

export default function Rightbar({ currentGroup }) {
  const [trends, setTrends] = useState([])
  useEffect(() => {
    if (!currentGroup) return
    getTrending(currentGroup.id).then(setTrends)
  }, [currentGroup])

  return (
    <div>
      <input className="search" placeholder="Search whispers" />
      <div style={{ marginTop: 16 }} className="card" >
        <div className="trend" style={{ fontWeight: 700 }}>Trending</div>
        {trends.length === 0 && <div className="trend">No trends yet. Be the first!</div>}
        {trends.map(t => (
          <div className="trend" key={t.id}>
            <div style={{ whiteSpace: 'pre-wrap' }}>{t.content}</div>
            <div className="meta">❤ {t.likes} · {new Date(t.created_at).toLocaleString()}</div>
          </div>
        ))}
        <div className="footer">Trends update from the last 24h.</div>
      </div>
    </div>
  )
}
