import React from 'react'

const Link = ({ children, href = '#' }) => <a href={href}>{children}</a>

export default function Sidebar() {
  return (
    <div>
      <div className="brand" style={{ marginBottom: 16 }}>whispr</div>
      <nav className="nav">
        <Link>Home</Link>
        <Link>Groups</Link>
        <Link>Trending</Link>
        <Link>About</Link>
      </nav>
      <div style={{ position: 'absolute', bottom: 16, left: 16, right: 16 }}>
        <button className="btn" style={{ width: '100%' }}>New Whisper</button>
      </div>
    </div>
  )
}
