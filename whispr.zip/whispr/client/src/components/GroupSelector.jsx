import React from 'react'

export default function GroupSelector({ groups, current, onChange }) {
  return (
    <select className="select" value={current?.id || ''} onChange={e => onChange(groups.find(g => g.id === e.target.value))}>
      {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
    </select>
  )
}
