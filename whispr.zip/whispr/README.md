# Whispr — Full-Stack (Node/SQLite + React/Vite)

## Run
### Server
```bash
cd server
cp .env.example .env
npm install
npm run dev
```

### Client
```bash
cd ../client
npm install
npm run dev
```

Open http://localhost:5173
