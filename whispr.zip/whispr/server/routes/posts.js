import { Router } from 'express';
import { rid } from '../utils/id.js';

export default function postRoutes({ db }) {
  const r = Router();

  // List posts for a group (reverse chronological)
  r.get('/', async (req, res) => {
    const { group_id, limit = 50, before } = req.query;
    if (!group_id) return res.status(400).json({ error: 'group_id required' });

    let sql = 'SELECT * FROM posts WHERE group_id = ?';
    const args = [group_id];
    if (before) { sql += ' AND created_at < ?'; args.push(before); }
    sql += ' ORDER BY datetime(created_at) DESC LIMIT ?';
    args.push(Number(limit));

    const rows = await db.all(sql, ...args);
    res.json(rows);
  });

  // Create a post
  r.post('/', async (req, res) => {
    const { content, group_id, reply_to } = req.body || {};
    if (!content || !group_id) return res.status(400).json({ error: 'content and group_id required' });
    const id = rid('pst_');
    await db.run(
      'INSERT INTO posts (id, user_id, group_id, content, reply_to) VALUES (?, ?, ?, ?, ?)',
      id, req.user.id, group_id, content.slice(0, 500), reply_to || null
    );
    const row = await db.get('SELECT * FROM posts WHERE id = ?', id);
    res.status(201).json(row);
  });

  // Like a post (toggle)
  r.post('/:id/like', async (req, res) => {
    const { id } = req.params;
    const userId = req.user.id;
    const liked = await db.get('SELECT 1 FROM post_likes WHERE post_id = ? AND user_id = ?', id, userId);
    if (liked) {
      await db.run('DELETE FROM post_likes WHERE post_id = ? AND user_id = ?', id, userId);
      await db.run('UPDATE posts SET likes = likes - 1 WHERE id = ? AND likes > 0', id);
      const p = await db.get('SELECT * FROM posts WHERE id = ?', id);
      return res.json({ liked: false, post: p });
    } else {
      await db.run('INSERT INTO post_likes (post_id, user_id) VALUES (?, ?)', id, userId);
      await db.run('UPDATE posts SET likes = likes + 1 WHERE id = ?', id);
      const p = await db.get('SELECT * FROM posts WHERE id = ?', id);
      return res.json({ liked: true, post: p });
    }
  });

  // Trending in a group (top liked in last 24h)
  r.get('/trending', async (req, res) => {
    const { group_id, limit = 10 } = req.query;
    if (!group_id) return res.status(400).json({ error: 'group_id required' });
    const rows = await db.all(
      `SELECT * FROM posts
       WHERE group_id = ? AND datetime(created_at) >= datetime('now', '-1 day')
       ORDER BY likes DESC, datetime(created_at) DESC
       LIMIT ?`,
      group_id, Number(limit)
    );
    res.json(rows);
  });

  return r;
}
