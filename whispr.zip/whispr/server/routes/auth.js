import { Router } from 'express';
import { rid } from '../utils/id.js';
import { signToken } from '../middleware/auth.js';

export default function authRoutes({ db, jwtSecret }) {
  const r = Router();

  // Create an anonymous user and return a JWT
  r.post('/anonymous', async (req, res) => {
    const id = rid('usr_');
    try {
      await db.run('INSERT INTO users (id) VALUES (?)', id);
      const token = signToken({ id }, jwtSecret);
      res.json({ token, user: { id } });
    } catch (e) {
      try {
        const id2 = rid('usr_');
        await db.run('INSERT INTO users (id) VALUES (?)', id2);
        const token = signToken({ id: id2 }, jwtSecret);
        res.json({ token, user: { id: id2 } });
      } catch (err) {
        res.status(500).json({ error: 'Failed to create user' });
      }
    }
  });

  return r;
}
