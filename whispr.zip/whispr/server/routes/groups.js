import { Router } from 'express';
import { rid } from '../utils/id.js';

export default function groupRoutes({ db }) {
  const r = Router();

  r.get('/', async (req, res) => {
    const rows = await db.all('SELECT * FROM groups ORDER BY name');
    res.json(rows);
  });

  r.post('/', async (req, res) => {
    const { name, region_code } = req.body || {};
    if (!name) return res.status(400).json({ error: 'name required' });
    const id = rid('grp_');
    try {
      await db.run('INSERT INTO groups (id, name, region_code) VALUES (?, ?, ?)', id, name, region_code || null);
      const row = await db.get('SELECT * FROM groups WHERE id = ?', id);
      res.status(201).json(row);
    } catch (e) {
      res.status(400).json({ error: 'Group may already exist' });
    }
  });

  return r;
}
