import jwt from 'jsonwebtoken';

export function signToken(payload, secret) {
  return jwt.sign(payload, secret, { expiresIn: '365d' });
}

export function authMiddleware(secret) {
  return function (req, res, next) {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Missing token' });
    try {
      const decoded = jwt.verify(token, secret);
      req.user = decoded; // { id }
      next();
    } catch (e) {
      return res.status(401).json({ error: 'Invalid token' });
    }
  };
}
