-- Users are anonymous. We keep only an id and created_at.
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Groups are region / community buckets (e.g., SRM, Panvel, etc.)
CREATE TABLE IF NOT EXISTS groups (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  region_code TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Posts with optional reply_to for threads
CREATE TABLE IF NOT EXISTS posts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  group_id TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  reply_to TEXT,
  likes INTEGER DEFAULT 0,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(group_id) REFERENCES groups(id) ON DELETE CASCADE,
  FOREIGN KEY(reply_to) REFERENCES posts(id) ON DELETE CASCADE
);

-- Basic like tracking to avoid double likes (anonymous but tied to user id)
CREATE TABLE IF NOT EXISTS post_likes (
  post_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (post_id, user_id),
  FOREIGN KEY(post_id) REFERENCES posts(id) ON DELETE CASCADE,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Seed a few groups if empty
INSERT OR IGNORE INTO groups (id, name, region_code) VALUES
  ('grp_srm', 'SRM University', 'KTR'),
  ('grp_panvel', 'Panvel Locals', 'PNV'),
  ('grp_mumbai', 'Mumbai Campus', 'MUM');
