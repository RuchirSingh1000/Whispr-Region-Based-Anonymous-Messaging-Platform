import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import { getDB } from './db.js';
import { readFile } from 'fs/promises';
import authRoutes from './routes/auth.js';
import groupRoutes from './routes/groups.js';
import postRoutes from './routes/posts.js';
import { authMiddleware } from './middleware/auth.js';

dotenv.config();

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'devsecret';
const DB_FILE = process.env.DATABASE_FILE || './whispr.db';
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || 'http://localhost:5173';

const app = express();
app.use(helmet());
app.use(cors({ origin: CLIENT_ORIGIN, credentials: true }));
app.use(express.json({ limit: '1mb' }));

const db = await getDB(DB_FILE);
const schema = await readFile(new URL('./schema.sql', import.meta.url));
await db.exec(schema.toString());

// Public
app.use('/api/auth', authRoutes({ db, jwtSecret: JWT_SECRET }));
app.use('/api/groups', groupRoutes({ db }));

// Protected
app.use('/api/posts', authMiddleware(JWT_SECRET), postRoutes({ db }));

app.get('/', (req, res) => res.json({ ok: true, service: 'whispr-api' }));

app.listen(PORT, () => console.log(`API on http://localhost:${PORT}`));
